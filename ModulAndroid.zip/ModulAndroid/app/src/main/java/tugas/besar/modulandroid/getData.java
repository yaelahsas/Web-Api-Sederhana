package tugas.besar.modulandroid;

import android.app.VoiceInteractor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class getData extends AppCompatActivity {
    String[] listArray={"ASP","C#","C++","HTML5","Javascript","Java","Objective-C","Perl","PHP","Python","Swift"};
    private static final String JSON_URL = "https://azharsaepudin.github.io/FootBallPlayer/AllPlayer.json";
    private ListView lv;
    private String nama;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_data);
        lv = findViewById(R.id.listNya);
        RequestQueue queue = Volley.newRequestQueue(this);
        final String url = "https://9482a852.ngrok.io/api/pengguna";
        JsonObjectRequest objectRequest = new JsonObjectRequest( Request.Method.GET,url,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                JSONArray data = null;
                try {

                    data = response.getJSONArray("pengguna");
                    List<String> data_array = new ArrayList<String>();
                    for (int i = 0; i < data.length(); i++) {

                        JSONObject c = data.getJSONObject(i);
                         nama = c.getString("nama");
                        //String email = c.getString("email");
                       // String password = c.getString("password");

                        //data_array.add(email);
                       // data_array.add(password);

                        data_array.add(nama);

                    }

                    Log.d("Responya = ", response.toString());
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getData.this,android.R.layout.simple_list_item_1,data_array);
                    lv.setAdapter(adapter);
                } catch (JSONException e) {

                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Error Volley = ",error.toString());
            }
        });
        queue.add(objectRequest);
    }
}

