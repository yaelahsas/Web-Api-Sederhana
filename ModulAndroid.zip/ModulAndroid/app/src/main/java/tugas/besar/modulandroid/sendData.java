package tugas.besar.modulandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class sendData extends AppCompatActivity implements View.OnClickListener {

     private Button kirim;
     private EditText tmpNama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_data);

        tmpNama = findViewById(R.id.namanya);
        kirim = findViewById(R.id.kirimData);
        kirim.setOnClickListener(this);

    }

    public void kirimDatanya(){

        RequestQueue MyrequestQueue = Volley.newRequestQueue(this);
        String url = "https://9482a852.ngrok.io/api/pengguna";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                tmpNama.setText("");
                Toast.makeText(sendData.this, response, Toast.LENGTH_SHORT).show();
                Log.d("Response Nya",response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                Toast.makeText(sendData.this,error.toString(),Toast.LENGTH_LONG).show();
            }
        }) {
            protected Map<String, String>getParams(){

                Map<String, String> MyData = new HashMap<String, String>();
                MyData.put("nama",tmpNama.getText().toString());
                return MyData;

            }
        };

        MyrequestQueue.add(stringRequest);

    }

    @Override
    public void onClick(View view) {
        if (view == kirim){

    kirimDatanya();

        }
    }

    public void Pindah(View view) {

        Intent pindah = new Intent(sendData.this,getData.class);
        startActivity(pindah);
    }
}
