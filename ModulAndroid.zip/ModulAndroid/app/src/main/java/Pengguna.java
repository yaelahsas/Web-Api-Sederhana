import java.io.Serializable;

/**
 * Created by user on 03/06/2019.
 */

public class Pengguna implements Serializable {

    String nama,email,password;

    public Pengguna(String nama, String email, String password) {
        this.nama = nama;
        this.email = email;
        this.password = password;
    }

    public String getNama() {
        return nama;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
